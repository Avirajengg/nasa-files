// Real Sun/Earth visibility from data/sites.json (made by export_sites.py).
// Pure functions, no React. All angles in degrees, times in UTC.

export interface Meta {
  start_utc: string; step_hours: number; n: number; heights_m: number[]
  scale: number; radius_scale: number; sun_radius: number[]; earth_radius: number[]
}
export interface SiteRaw {
  id: string; name: string; lat: number; lon: number; elev_m: number
  tile_range_median_m: number; horizon_source?: string
  horizon: Record<string, number[]>; summary: Record<string, Record<string, number>>
  sun_az: number[]; sun_el: number[]; earth_az: number[]; earth_el: number[]
}
export interface SitesFile { meta: Meta; sites: SiteRaw[] }

export interface Site {
  id: string; name: string; lat: number; lon: number; elevM: number
  rangeM: number; source?: string
  hz: Record<string, Float64Array>          // horizon elevation per 1 deg azimuth, by height
  sunAz: Float64Array; sunEl: Float64Array; earthAz: Float64Array; earthEl: Float64Array
}
export interface Dataset {
  t0: number; stepH: number; n: number; heights: number[]
  sunR: Float64Array; earthR: Float64Array; sites: Site[]
}
export interface Series { sunC: Uint8Array; sunA: Uint8Array; earthC: Uint8Array; earthA: Uint8Array }
export interface Metrics {
  hours: number; sunCenterPct: number; sunAnyPct: number; earthCenterPct: number; earthAnyPct: number
  longestSunDarkH: number; longestSunLitH: number; longestEarthWindowH: number; longestEarthGapH: number
}
export interface Window { start: Date; end: Date; hours: number }

const dec = (a: number[], k: number) => Float64Array.from(a, v => v / k)

export function loadDataset(f: SitesFile): Dataset {
  const m = f.meta, k = m.scale
  return {
    t0: Date.parse(m.start_utc + 'Z'), stepH: m.step_hours, n: m.n, heights: m.heights_m,
    sunR: dec(m.sun_radius, m.radius_scale), earthR: dec(m.earth_radius, m.radius_scale),
    sites: f.sites.map(s => ({
      id: s.id, name: s.name, lat: s.lat, lon: s.lon, elevM: s.elev_m,
      rangeM: s.tile_range_median_m, source: s.horizon_source,
      hz: Object.fromEntries(Object.entries(s.horizon).map(([h, a]) => [h, dec(a, k)])),
      sunAz: dec(s.sun_az, k), sunEl: dec(s.sun_el, k), earthAz: dec(s.earth_az, k), earthEl: dec(s.earth_el, k),
    })),
  }
}

/** Terrain horizon elevation at an azimuth (linear interpolation, wraps at 360). */
export function horizonAt(hz: Float64Array, az: number): number {
  const a = ((az % 360) + 360) % 360, i = Math.floor(a), f = a - i
  return hz[i % 360] * (1 - f) + hz[(i + 1) % 360] * f
}

export const timeAt = (ds: Dataset, i: number) => new Date(ds.t0 + i * ds.stepH * 3600e3)

/** Sample index for a date, clamped to the data range. */
export function indexAt(ds: Dataset, d: Date | string): number {
  const t = typeof d === 'string' ? Date.parse(d + (d.length <= 10 ? 'T00:00:00Z' : '')) : d.getTime()
  return Math.min(ds.n - 1, Math.max(0, Math.round((t - ds.t0) / (ds.stepH * 3600e3))))
}

/** Visibility of Sun and Earth for samples [i0, i1). "C" = centre above horizon, "A" = any part of the disk. */
export function computeSeries(ds: Dataset, s: Site, h: number, i0 = 0, i1 = ds.n): Series {
  const hz = s.hz[String(h)], n = i1 - i0
  const out: Series = { sunC: new Uint8Array(n), sunA: new Uint8Array(n), earthC: new Uint8Array(n), earthA: new Uint8Array(n) }
  for (let k = 0; k < n; k++) {
    const i = i0 + k, hs = horizonAt(hz, s.sunAz[i]), he = horizonAt(hz, s.earthAz[i])
    out.sunC[k] = s.sunEl[i] > hs ? 1 : 0
    out.sunA[k] = s.sunEl[i] + ds.sunR[i] > hs ? 1 : 0
    out.earthC[k] = s.earthEl[i] > he ? 1 : 0
    out.earthA[k] = s.earthEl[i] + ds.earthR[i] > he ? 1 : 0
  }
  return out
}

const pct = (a: Uint8Array) => { let c = 0; for (const v of a) c += v; return a.length ? (100 * c) / a.length : 0 }
export function longestRun(a: Uint8Array, value: 0 | 1, stepH: number): number {
  let best = 0, run = 0
  for (const v of a) { if (v === value) { run++; if (run > best) best = run } else run = 0 }
  return best * stepH
}

export function computeMetrics(ds: Dataset, s: Site, h: number, i0 = 0, i1 = ds.n): Metrics & { series: Series } {
  const series = computeSeries(ds, s, h, i0, i1)
  return {
    series, hours: (i1 - i0) * ds.stepH,
    sunCenterPct: pct(series.sunC), sunAnyPct: pct(series.sunA),
    earthCenterPct: pct(series.earthC), earthAnyPct: pct(series.earthA),
    longestSunDarkH: longestRun(series.sunA, 0, ds.stepH), longestSunLitH: longestRun(series.sunA, 1, ds.stepH),
    longestEarthWindowH: longestRun(series.earthC, 1, ds.stepH), longestEarthGapH: longestRun(series.earthC, 0, ds.stepH),
  }
}

/** Contiguous runs where mask == 1, as dated windows (for an Earth-comms window table). */
export function windows(ds: Dataset, mask: Uint8Array, i0 = 0): Window[] {
  const out: Window[] = []
  let start = -1
  for (let k = 0; k <= mask.length; k++) {
    const on = k < mask.length && mask[k] === 1
    if (on && start < 0) start = k
    if (!on && start >= 0) {
      out.push({ start: timeAt(ds, i0 + start), end: timeAt(ds, i0 + k), hours: (k - start) * ds.stepH })
      start = -1
    }
  }
  return out
}

/** Everything about one instant, e.g. for a timeline slider. */
export function stateAt(ds: Dataset, s: Site, h: number, i: number) {
  const hz = s.hz[String(h)], hs = horizonAt(hz, s.sunAz[i]), he = horizonAt(hz, s.earthAz[i])
  return {
    time: timeAt(ds, i),
    sun: { az: s.sunAz[i], el: s.sunEl[i], horizon: hs, lit: s.sunEl[i] + ds.sunR[i] > hs },
    earth: { az: s.earthAz[i], el: s.earthEl[i], horizon: he, visible: s.earthEl[i] > he },
  }
}
