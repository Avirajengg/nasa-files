import { useEffect, useState } from 'react'
import { loadDataset, type Dataset, type SitesFile } from '../lib/visibility'

/** Loads public/sites.json once and decodes it. */
export function useSites() {
  const [data, setData] = useState<Dataset | null>(null)
  const [error, setError] = useState<string | null>(null)
  useEffect(() => {
    let live = true
    fetch(import.meta.env.BASE_URL + 'sites.json')
      .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json() as Promise<SitesFile> })
      .then(f => { if (live) setData(loadDataset(f)) })
      .catch(e => { if (live) setError(String(e)) })
    return () => { live = false }
  }, [])
  return { data, error, loading: !data && !error }
}
